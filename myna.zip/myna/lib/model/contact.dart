class Contact {
  String name;
  String password;
  String phone = '';
  String email = '';
  String user_type = '';
  String categoty = '';
  var adress = {
    "country":  "",
    "state"   :  "",
    "district": "",
    "city": "",
    "pin" : "" ,
  };
}