package com.example.myna

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
