1. import all dependency
2. open speech_recognition.dart libarary by ctrl+(left click) in stt2.dart
3. delete its code and paste from this site :  https://github.com/rxlabz/speech_recognition/blob/master/lib/speech_recognition.dart
4. flutter clean
5. flutter run



Note: other functionalities are commented like sign.. only for testing sst.
        (Can also test tts by uncommenting in main.dart)

    working on language support.....
